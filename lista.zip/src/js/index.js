import * as mdb from 'mdb-ui-kit';


export default {
  mdb,
};
